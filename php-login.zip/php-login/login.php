<?php 

session_start();

if (isset ($_SESSION['user_id'])){
    header('Location: /PHP-LOGIN');
}
require 'database.php';

if(!empty ($_POST['usuario']) && !empty($_POST['password'])){
    $records = $conn-> prepare('SELECT id, usuario, password from users where usuario = :usuario');
    $records ->bindParam(':usuario', $_POST['usuario']);
    $records->execute();
    $results = $records->fetch(PDO :: FETCH_ASSOC);

    $message = '';

    if (count($results)> 0 && password_verify($_POST['password'], $results['password'])){
        $_SESSION['user_id'] = $results['id'];
        header('Location: /PHP-LOGIN');
    }else{
        $message = 'Lo sentimos pero al parecer tus credenciales no coinciden';
    }
}

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Inicio de sesion</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,700;1,800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="interfaz/css/style.css">
</head>
<body>
<header>
    <a href="/PHP-LOGIN">Regresar al menu principal</a>
</header>

<?php if(!empty($message)): ?>
    <p><?= $message?></p>
<?php endif; ?>

    <h1>Inicio de sesion</h1>
    <span> o <a href="signup.php">registrese</a></span>
    

<form action ="login.php" method="POST">
        <input type="text" name="usuario" placeholder="Digite su nombre de usuario">
        <input type="password" name="password" placeholder="ingresa tu contrasena">
        <input type="submit" value="Confirmar">
    </form> 
</body>
</html>