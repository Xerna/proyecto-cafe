<?php
    session_start();

    require 'database.php';

    if(isset($_SESSION['user_id'])){
        $records = $conn->prepare('SELECT id, usuario, password FROM users where id = :id');
        $records -> bindParam(':id', $_SESSION['user_id']);
        $records ->execute();
        $results = $records->fetch(PDO::FETCH_ASSOC);

        $user = null;

        if(count($results)>0){
            $user = $results;
        }
    }
?>


<!DOCTYPE html>
<html>
    <head> 
        <meta charset="utf-8">
        <title>Bienvenido</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,700;1,800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="interfaz/css/style.css">
    </head>
    <body>
        <header>
            <a>¡BIENVENIDOS A NUESTRA CAFETERIA!</a>
        </header>
       <?php if (!empty($user)): ?>
        <br> Bienvenido al sistema <?= $user['usuario'];?>
        <br> Tu inicio de sesion fue exitoso
        <a href ="logout.php">
            Cerrar sesion
       </a>

       <?php else: ?>
        <h1> Por favor inicia sesion o registrate</h1>
        <a href="login.php">Iniciar sesion</a> o 
        <a href="signup.php">registrate</a> 
        <?php endif; ?>       
    </body>
</html>