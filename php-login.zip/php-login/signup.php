<?php 
    require 'database.php';
    
    $message='';

    if (!empty($_POST['usuario']) && !empty($_POST['password'])) {
        $sql = "INSERT INTO users (usuario, password) VALUES (:usuario, :password)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':usuario',$_POST['usuario']);
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $stmt->bindParam(':password',$password);
        
        if ($stmt->execute()){
            $message = "El usuario fue creado exitosamente";
        }else{
            $message = "Ha ocurrido un error creando su usuario";
        }
    }    
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Registro de usuario</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,700;1,800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="interfaz/css/style.css">
</head>
<body>
<header>
    <a href="/PHP-LOGIN">Regresar al menu principal</a>
</header>
<?php if(!empty($message)): ?>
    <p><?= $message?></p>
<?php endif; ?>

<h1> Registro de usuario</h1>
<span> or <a href="login.php">Inicie sesion</a></span>

<form action ="signup.php" method="post">
        <input type="text" name="usuario" placeholder="Digite su nombre de usuario">
        <input type="password" name="password" placeholder="ingresa tu contrasena">
        <input type="submit" value="Confirmar">
    </form>     
</body>
</html>  